<?php
echo $_GET['cmd'];
?>