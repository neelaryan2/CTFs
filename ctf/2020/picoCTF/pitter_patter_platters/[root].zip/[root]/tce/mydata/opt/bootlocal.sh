#!/bin/sh
# put other system startup commands here
/usr/local/etc/init.d/openssh start
/usr/local/etc/init.d/nginx start
